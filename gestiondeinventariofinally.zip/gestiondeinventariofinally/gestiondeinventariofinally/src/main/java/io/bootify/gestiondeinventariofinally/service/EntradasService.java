package io.bootify.gestiondeinventariofinally.service;

import io.bootify.gestiondeinventariofinally.domain.Admin;
import io.bootify.gestiondeinventariofinally.domain.DetallesEntradas;
import io.bootify.gestiondeinventariofinally.domain.Entradas;
import io.bootify.gestiondeinventariofinally.model.EntradasDTO;
import io.bootify.gestiondeinventariofinally.repos.AdminRepository;
import io.bootify.gestiondeinventariofinally.repos.DetallesEntradasRepository;
import io.bootify.gestiondeinventariofinally.repos.EntradasRepository;
import io.bootify.gestiondeinventariofinally.util.NotFoundException;
import io.bootify.gestiondeinventariofinally.util.ReferencedWarning;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class EntradasService {

    private final EntradasRepository entradasRepository;
    private final AdminRepository adminRepository;
    private final DetallesEntradasRepository detallesEntradasRepository;

    public EntradasService(final EntradasRepository entradasRepository,
            final AdminRepository adminRepository,
            final DetallesEntradasRepository detallesEntradasRepository) {
        this.entradasRepository = entradasRepository;
        this.adminRepository = adminRepository;
        this.detallesEntradasRepository = detallesEntradasRepository;
    }

    public List<EntradasDTO> findAll() {
        final List<Entradas> entradases = entradasRepository.findAll(Sort.by("id"));
        return entradases.stream()
                .map(entradas -> mapToDTO(entradas, new EntradasDTO()))
                .toList();
    }

    public EntradasDTO get(final Long id) {
        return entradasRepository.findById(id)
                .map(entradas -> mapToDTO(entradas, new EntradasDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Long create(final EntradasDTO entradasDTO) {
        final Entradas entradas = new Entradas();
        mapToEntity(entradasDTO, entradas);
        return entradasRepository.save(entradas).getId();
    }

    public void update(final Long id, final EntradasDTO entradasDTO) {
        final Entradas entradas = entradasRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(entradasDTO, entradas);
        entradasRepository.save(entradas);
    }

    public void delete(final Long id) {
        entradasRepository.deleteById(id);
    }

    private EntradasDTO mapToDTO(final Entradas entradas, final EntradasDTO entradasDTO) {
        entradasDTO.setId(entradas.getId());
        entradasDTO.setFecha(entradas.getFecha());
        entradasDTO.setCantidad(entradas.getCantidad());
        entradasDTO.setDescripcion(entradas.getDescripcion());
        entradasDTO.setIdAdmin(entradas.getIdAdmin() == null ? null : entradas.getIdAdmin().getId());
        return entradasDTO;
    }

    private Entradas mapToEntity(final EntradasDTO entradasDTO, final Entradas entradas) {
        entradas.setFecha(entradasDTO.getFecha());
        entradas.setCantidad(entradasDTO.getCantidad());
        entradas.setDescripcion(entradasDTO.getDescripcion());
        final Admin idAdmin = entradasDTO.getIdAdmin() == null ? null : adminRepository.findById(entradasDTO.getIdAdmin())
                .orElseThrow(() -> new NotFoundException("idAdmin not found"));
        entradas.setIdAdmin(idAdmin);
        return entradas;
    }

    public ReferencedWarning getReferencedWarning(final Long id) {
        final ReferencedWarning referencedWarning = new ReferencedWarning();
        final Entradas entradas = entradasRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        final DetallesEntradas idEntradaDetallesEntradas = detallesEntradasRepository.findFirstByIdEntrada(entradas);
        if (idEntradaDetallesEntradas != null) {
            referencedWarning.setKey("entradas.detallesEntradas.idEntrada.referenced");
            referencedWarning.addParam(idEntradaDetallesEntradas.getId());
            return referencedWarning;
        }
        return null;
    }

}
