package io.bootify.gestiondeinventariofinally.repos;

import io.bootify.gestiondeinventariofinally.domain.DetallesEntradas;
import io.bootify.gestiondeinventariofinally.domain.Entradas;
import io.bootify.gestiondeinventariofinally.domain.Insumos;
import org.springframework.data.jpa.repository.JpaRepository;


public interface DetallesEntradasRepository extends JpaRepository<DetallesEntradas, Long> {

    DetallesEntradas findFirstByIdEntrada(Entradas entradas);

    DetallesEntradas findFirstByIdInsumo(Insumos insumos);

}
