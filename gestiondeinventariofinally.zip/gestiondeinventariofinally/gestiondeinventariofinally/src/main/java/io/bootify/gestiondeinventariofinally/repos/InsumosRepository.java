package io.bootify.gestiondeinventariofinally.repos;

import io.bootify.gestiondeinventariofinally.domain.Insumos;
import org.springframework.data.jpa.repository.JpaRepository;


public interface InsumosRepository extends JpaRepository<Insumos, Long> {
}
