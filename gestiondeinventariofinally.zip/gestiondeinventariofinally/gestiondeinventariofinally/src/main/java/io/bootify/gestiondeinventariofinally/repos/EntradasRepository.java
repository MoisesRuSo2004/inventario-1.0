package io.bootify.gestiondeinventariofinally.repos;

import io.bootify.gestiondeinventariofinally.domain.Admin;
import io.bootify.gestiondeinventariofinally.domain.Entradas;
import org.springframework.data.jpa.repository.JpaRepository;


public interface EntradasRepository extends JpaRepository<Entradas, Long> {

    Entradas findFirstByIdAdmin(Admin admin);

}
