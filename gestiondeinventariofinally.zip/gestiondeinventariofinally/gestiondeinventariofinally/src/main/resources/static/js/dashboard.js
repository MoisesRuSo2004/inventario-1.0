// Archivo: /js/dashboard.js

// Inicialización de la gráfica de insumos más usados
document.addEventListener("DOMContentLoaded", function () {
  var ctx = document.getElementById("insumosChart").getContext("2d");
  var insumosChart = new Chart(ctx, {
    type: "bar", // Tipo de gráfica
    data: {
      labels: ["Desinfectante", "Jabón", "Guantes", "Máscara", "Alcohol"], // Insumos más usados
      datasets: [
        {
          label: "Cantidad Usada",
          data: [150, 200, 120, 180, 90], // Cantidad de cada insumo
          backgroundColor: "rgba(255, 193, 7, 0.8)", // Color de las barras
          borderColor: "rgba(255, 193, 7, 1)", // Borde de las barras
          borderWidth: 1,
        },
      ],
    },
    options: {
      responsive: true,
      scales: {
        y: {
          beginAtZero: true,
        },
      },
    },
  });
});
