package io.bootify.gestiondeinventariofinally.service;

import io.bootify.gestiondeinventariofinally.domain.DetallesEntradas;
import io.bootify.gestiondeinventariofinally.domain.DetallesSalidas;
import io.bootify.gestiondeinventariofinally.domain.Insumos;
import io.bootify.gestiondeinventariofinally.model.InsumosDTO;
import io.bootify.gestiondeinventariofinally.repos.DetallesEntradasRepository;
import io.bootify.gestiondeinventariofinally.repos.DetallesSalidasRepository;
import io.bootify.gestiondeinventariofinally.repos.InsumosRepository;
import io.bootify.gestiondeinventariofinally.util.NotFoundException;
import io.bootify.gestiondeinventariofinally.util.ReferencedWarning;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class InsumosService {

    private final InsumosRepository insumosRepository;
    private final DetallesEntradasRepository detallesEntradasRepository;
    private final DetallesSalidasRepository detallesSalidasRepository;

    public InsumosService(final InsumosRepository insumosRepository,
            final DetallesEntradasRepository detallesEntradasRepository,
            final DetallesSalidasRepository detallesSalidasRepository) {
        this.insumosRepository = insumosRepository;
        this.detallesEntradasRepository = detallesEntradasRepository;
        this.detallesSalidasRepository = detallesSalidasRepository;
    }

    public List<InsumosDTO> findAll() {
        final List<Insumos> insumoses = insumosRepository.findAll(Sort.by("id"));
        return insumoses.stream()
                .map(insumos -> mapToDTO(insumos, new InsumosDTO()))
                .toList();
    }

    public InsumosDTO get(final Long id) {
        return insumosRepository.findById(id)
                .map(insumos -> mapToDTO(insumos, new InsumosDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Long create(final InsumosDTO insumosDTO) {
        final Insumos insumos = new Insumos();
        mapToEntity(insumosDTO, insumos);
        return insumosRepository.save(insumos).getId();
    }

    public void update(final Long id, final InsumosDTO insumosDTO) {
        final Insumos insumos = insumosRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(insumosDTO, insumos);
        insumosRepository.save(insumos);
    }

    public void delete(final Long id) {
        insumosRepository.deleteById(id);
    }

    private InsumosDTO mapToDTO(final Insumos insumos, final InsumosDTO insumosDTO) {
        insumosDTO.setId(insumos.getId());
        insumosDTO.setNombre(insumos.getNombre());
        insumosDTO.setStock(insumos.getStock());
        return insumosDTO;
    }

    private Insumos mapToEntity(final InsumosDTO insumosDTO, final Insumos insumos) {
        insumos.setNombre(insumosDTO.getNombre());
        insumos.setStock(insumosDTO.getStock());
        return insumos;
    }

    public ReferencedWarning getReferencedWarning(final Long id) {
        final ReferencedWarning referencedWarning = new ReferencedWarning();
        final Insumos insumos = insumosRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        final DetallesEntradas idInsumoDetallesEntradas = detallesEntradasRepository.findFirstByIdInsumo(insumos);
        if (idInsumoDetallesEntradas != null) {
            referencedWarning.setKey("insumos.detallesEntradas.idInsumo.referenced");
            referencedWarning.addParam(idInsumoDetallesEntradas.getId());
            return referencedWarning;
        }
        final DetallesSalidas idInsumoDetallesSalidas = detallesSalidasRepository.findFirstByIdInsumo(insumos);
        if (idInsumoDetallesSalidas != null) {
            referencedWarning.setKey("insumos.detallesSalidas.idInsumo.referenced");
            referencedWarning.addParam(idInsumoDetallesSalidas.getId());
            return referencedWarning;
        }
        return null;
    }

}
