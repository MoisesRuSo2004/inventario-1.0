package io.bootify.gestiondeinventariofinally.service;

import io.bootify.gestiondeinventariofinally.domain.DetallesSalidas;
import io.bootify.gestiondeinventariofinally.domain.Insumos;
import io.bootify.gestiondeinventariofinally.domain.Salidas;
import io.bootify.gestiondeinventariofinally.model.DetallesSalidasDTO;
import io.bootify.gestiondeinventariofinally.repos.DetallesSalidasRepository;
import io.bootify.gestiondeinventariofinally.repos.InsumosRepository;
import io.bootify.gestiondeinventariofinally.repos.SalidasRepository;
import io.bootify.gestiondeinventariofinally.util.NotFoundException;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class DetallesSalidasService {

    private final DetallesSalidasRepository detallesSalidasRepository;
    private final SalidasRepository salidasRepository;
    private final InsumosRepository insumosRepository;

    public DetallesSalidasService(final DetallesSalidasRepository detallesSalidasRepository,
            final SalidasRepository salidasRepository, final InsumosRepository insumosRepository) {
        this.detallesSalidasRepository = detallesSalidasRepository;
        this.salidasRepository = salidasRepository;
        this.insumosRepository = insumosRepository;
    }

    public List<DetallesSalidasDTO> findAll() {
        final List<DetallesSalidas> detallesSalidases = detallesSalidasRepository.findAll(Sort.by("id"));
        return detallesSalidases.stream()
                .map(detallesSalidas -> mapToDTO(detallesSalidas, new DetallesSalidasDTO()))
                .toList();
    }

    public DetallesSalidasDTO get(final Long id) {
        return detallesSalidasRepository.findById(id)
                .map(detallesSalidas -> mapToDTO(detallesSalidas, new DetallesSalidasDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Long create(final DetallesSalidasDTO detallesSalidasDTO) {
        final DetallesSalidas detallesSalidas = new DetallesSalidas();
        mapToEntity(detallesSalidasDTO, detallesSalidas);
        return detallesSalidasRepository.save(detallesSalidas).getId();
    }

    public void update(final Long id, final DetallesSalidasDTO detallesSalidasDTO) {
        final DetallesSalidas detallesSalidas = detallesSalidasRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(detallesSalidasDTO, detallesSalidas);
        detallesSalidasRepository.save(detallesSalidas);
    }

    public void delete(final Long id) {
        detallesSalidasRepository.deleteById(id);
    }

    private DetallesSalidasDTO mapToDTO(final DetallesSalidas detallesSalidas,
            final DetallesSalidasDTO detallesSalidasDTO) {
        detallesSalidasDTO.setId(detallesSalidas.getId());
        detallesSalidasDTO.setNombre(detallesSalidas.getNombre());
        detallesSalidasDTO.setCantidad(detallesSalidas.getCantidad());
        detallesSalidasDTO.setIdSalida(detallesSalidas.getIdSalida() == null ? null : detallesSalidas.getIdSalida().getId());
        detallesSalidasDTO.setIdInsumo(detallesSalidas.getIdInsumo() == null ? null : detallesSalidas.getIdInsumo().getId());
        return detallesSalidasDTO;
    }

    private DetallesSalidas mapToEntity(final DetallesSalidasDTO detallesSalidasDTO,
            final DetallesSalidas detallesSalidas) {
        detallesSalidas.setNombre(detallesSalidasDTO.getNombre());
        detallesSalidas.setCantidad(detallesSalidasDTO.getCantidad());
        final Salidas idSalida = detallesSalidasDTO.getIdSalida() == null ? null : salidasRepository.findById(detallesSalidasDTO.getIdSalida())
                .orElseThrow(() -> new NotFoundException("idSalida not found"));
        detallesSalidas.setIdSalida(idSalida);
        final Insumos idInsumo = detallesSalidasDTO.getIdInsumo() == null ? null : insumosRepository.findById(detallesSalidasDTO.getIdInsumo())
                .orElseThrow(() -> new NotFoundException("idInsumo not found"));
        detallesSalidas.setIdInsumo(idInsumo);
        return detallesSalidas;
    }

}
