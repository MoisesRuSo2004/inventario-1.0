package io.bootify.gestiondeinventariofinally.controller;

import io.bootify.gestiondeinventariofinally.domain.Entradas;
import io.bootify.gestiondeinventariofinally.domain.Insumos;
import io.bootify.gestiondeinventariofinally.model.DetallesEntradasDTO;
import io.bootify.gestiondeinventariofinally.repos.EntradasRepository;
import io.bootify.gestiondeinventariofinally.repos.InsumosRepository;
import io.bootify.gestiondeinventariofinally.service.DetallesEntradasService;
import io.bootify.gestiondeinventariofinally.util.CustomCollectors;
import io.bootify.gestiondeinventariofinally.util.WebUtils;
import jakarta.validation.Valid;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;


@Controller
@RequestMapping("/detallesEntradass")
public class DetallesEntradasController {

    private final DetallesEntradasService detallesEntradasService;
    private final EntradasRepository entradasRepository;
    private final InsumosRepository insumosRepository;

    public DetallesEntradasController(final DetallesEntradasService detallesEntradasService,
            final EntradasRepository entradasRepository,
            final InsumosRepository insumosRepository) {
        this.detallesEntradasService = detallesEntradasService;
        this.entradasRepository = entradasRepository;
        this.insumosRepository = insumosRepository;
    }

    @ModelAttribute
    public void prepareContext(final Model model) {
        model.addAttribute("idEntradaValues", entradasRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(Entradas::getId, Entradas::getId)));
        model.addAttribute("idInsumoValues", insumosRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(Insumos::getId, Insumos::getNombre)));
    }

    @GetMapping
    public String list(final Model model) {
        model.addAttribute("detallesEntradases", detallesEntradasService.findAll());
        return "detallesEntradas/list";
    }

    @GetMapping("/add")
    public String add(
            @ModelAttribute("detallesEntradas") final DetallesEntradasDTO detallesEntradasDTO) {
        return "detallesEntradas/add";
    }

    @PostMapping("/add")
    public String add(
            @ModelAttribute("detallesEntradas") @Valid final DetallesEntradasDTO detallesEntradasDTO,
            final BindingResult bindingResult, final RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "detallesEntradas/add";
        }
        detallesEntradasService.create(detallesEntradasDTO);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_SUCCESS, WebUtils.getMessage("detallesEntradas.create.success"));
        return "redirect:/detallesEntradass";
    }

    @GetMapping("/edit/{id}")
    public String edit(@PathVariable(name = "id") final Long id, final Model model) {
        model.addAttribute("detallesEntradas", detallesEntradasService.get(id));
        return "detallesEntradas/edit";
    }

    @PostMapping("/edit/{id}")
    public String edit(@PathVariable(name = "id") final Long id,
            @ModelAttribute("detallesEntradas") @Valid final DetallesEntradasDTO detallesEntradasDTO,
            final BindingResult bindingResult, final RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "detallesEntradas/edit";
        }
        detallesEntradasService.update(id, detallesEntradasDTO);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_SUCCESS, WebUtils.getMessage("detallesEntradas.update.success"));
        return "redirect:/detallesEntradass";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable(name = "id") final Long id,
            final RedirectAttributes redirectAttributes) {
        detallesEntradasService.delete(id);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_INFO, WebUtils.getMessage("detallesEntradas.delete.success"));
        return "redirect:/detallesEntradass";
    }

}
