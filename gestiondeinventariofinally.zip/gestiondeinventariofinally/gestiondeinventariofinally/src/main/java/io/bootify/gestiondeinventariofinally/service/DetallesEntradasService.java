package io.bootify.gestiondeinventariofinally.service;

import io.bootify.gestiondeinventariofinally.domain.DetallesEntradas;
import io.bootify.gestiondeinventariofinally.domain.Entradas;
import io.bootify.gestiondeinventariofinally.domain.Insumos;
import io.bootify.gestiondeinventariofinally.model.DetallesEntradasDTO;
import io.bootify.gestiondeinventariofinally.repos.DetallesEntradasRepository;
import io.bootify.gestiondeinventariofinally.repos.EntradasRepository;
import io.bootify.gestiondeinventariofinally.repos.InsumosRepository;
import io.bootify.gestiondeinventariofinally.util.NotFoundException;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class DetallesEntradasService {

    private final DetallesEntradasRepository detallesEntradasRepository;
    private final EntradasRepository entradasRepository;
    private final InsumosRepository insumosRepository;

    public DetallesEntradasService(final DetallesEntradasRepository detallesEntradasRepository,
            final EntradasRepository entradasRepository,
            final InsumosRepository insumosRepository) {
        this.detallesEntradasRepository = detallesEntradasRepository;
        this.entradasRepository = entradasRepository;
        this.insumosRepository = insumosRepository;
    }

    public List<DetallesEntradasDTO> findAll() {
        final List<DetallesEntradas> detallesEntradases = detallesEntradasRepository.findAll(Sort.by("id"));
        return detallesEntradases.stream()
                .map(detallesEntradas -> mapToDTO(detallesEntradas, new DetallesEntradasDTO()))
                .toList();
    }

    public DetallesEntradasDTO get(final Long id) {
        return detallesEntradasRepository.findById(id)
                .map(detallesEntradas -> mapToDTO(detallesEntradas, new DetallesEntradasDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Long create(final DetallesEntradasDTO detallesEntradasDTO) {
        final DetallesEntradas detallesEntradas = new DetallesEntradas();
        mapToEntity(detallesEntradasDTO, detallesEntradas);
        return detallesEntradasRepository.save(detallesEntradas).getId();
    }

    public void update(final Long id, final DetallesEntradasDTO detallesEntradasDTO) {
        final DetallesEntradas detallesEntradas = detallesEntradasRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(detallesEntradasDTO, detallesEntradas);
        detallesEntradasRepository.save(detallesEntradas);
    }

    public void delete(final Long id) {
        detallesEntradasRepository.deleteById(id);
    }

    private DetallesEntradasDTO mapToDTO(final DetallesEntradas detallesEntradas,
            final DetallesEntradasDTO detallesEntradasDTO) {
        detallesEntradasDTO.setId(detallesEntradas.getId());
        detallesEntradasDTO.setNombre(detallesEntradas.getNombre());
        detallesEntradasDTO.setCantidad(detallesEntradas.getCantidad());
        detallesEntradasDTO.setIdEntrada(detallesEntradas.getIdEntrada() == null ? null : detallesEntradas.getIdEntrada().getId());
        detallesEntradasDTO.setIdInsumo(detallesEntradas.getIdInsumo() == null ? null : detallesEntradas.getIdInsumo().getId());
        return detallesEntradasDTO;
    }

    private DetallesEntradas mapToEntity(final DetallesEntradasDTO detallesEntradasDTO,
            final DetallesEntradas detallesEntradas) {
        detallesEntradas.setNombre(detallesEntradasDTO.getNombre());
        detallesEntradas.setCantidad(detallesEntradasDTO.getCantidad());
        final Entradas idEntrada = detallesEntradasDTO.getIdEntrada() == null ? null : entradasRepository.findById(detallesEntradasDTO.getIdEntrada())
                .orElseThrow(() -> new NotFoundException("idEntrada not found"));
        detallesEntradas.setIdEntrada(idEntrada);
        final Insumos idInsumo = detallesEntradasDTO.getIdInsumo() == null ? null : insumosRepository.findById(detallesEntradasDTO.getIdInsumo())
                .orElseThrow(() -> new NotFoundException("idInsumo not found"));
        detallesEntradas.setIdInsumo(idInsumo);
        return detallesEntradas;
    }

}
