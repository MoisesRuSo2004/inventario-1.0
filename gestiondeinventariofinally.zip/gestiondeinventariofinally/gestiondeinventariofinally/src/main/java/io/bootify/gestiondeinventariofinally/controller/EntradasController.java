package io.bootify.gestiondeinventariofinally.controller;

import io.bootify.gestiondeinventariofinally.domain.Admin;
import io.bootify.gestiondeinventariofinally.model.EntradasDTO;
import io.bootify.gestiondeinventariofinally.repos.AdminRepository;
import io.bootify.gestiondeinventariofinally.service.EntradasService;
import io.bootify.gestiondeinventariofinally.util.CustomCollectors;
import io.bootify.gestiondeinventariofinally.util.ReferencedWarning;
import io.bootify.gestiondeinventariofinally.util.WebUtils;
import jakarta.validation.Valid;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;


@Controller
@RequestMapping("/entradass")
public class EntradasController {

    private final EntradasService entradasService;
    private final AdminRepository adminRepository;

    public EntradasController(final EntradasService entradasService,
            final AdminRepository adminRepository) {
        this.entradasService = entradasService;
        this.adminRepository = adminRepository;
    }

    @ModelAttribute
    public void prepareContext(final Model model) {
        model.addAttribute("idAdminValues", adminRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(Admin::getId, Admin::getUsuario)));
    }

    @GetMapping
    public String list(final Model model) {
        model.addAttribute("entradases", entradasService.findAll());
        return "entradas/list";
    }

    @GetMapping("/add")
    public String add(@ModelAttribute("entradas") final EntradasDTO entradasDTO) {
        return "entradas/add";
    }

    @PostMapping("/add")
    public String add(@ModelAttribute("entradas") @Valid final EntradasDTO entradasDTO,
            final BindingResult bindingResult, final RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "entradas/add";
        }
        entradasService.create(entradasDTO);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_SUCCESS, WebUtils.getMessage("entradas.create.success"));
        return "redirect:/entradass";
    }

    @GetMapping("/edit/{id}")
    public String edit(@PathVariable(name = "id") final Long id, final Model model) {
        model.addAttribute("entradas", entradasService.get(id));
        return "entradas/edit";
    }

    @PostMapping("/edit/{id}")
    public String edit(@PathVariable(name = "id") final Long id,
            @ModelAttribute("entradas") @Valid final EntradasDTO entradasDTO,
            final BindingResult bindingResult, final RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "entradas/edit";
        }
        entradasService.update(id, entradasDTO);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_SUCCESS, WebUtils.getMessage("entradas.update.success"));
        return "redirect:/entradass";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable(name = "id") final Long id,
            final RedirectAttributes redirectAttributes) {
        final ReferencedWarning referencedWarning = entradasService.getReferencedWarning(id);
        if (referencedWarning != null) {
            redirectAttributes.addFlashAttribute(WebUtils.MSG_ERROR,
                    WebUtils.getMessage(referencedWarning.getKey(), referencedWarning.getParams().toArray()));
        } else {
            entradasService.delete(id);
            redirectAttributes.addFlashAttribute(WebUtils.MSG_INFO, WebUtils.getMessage("entradas.delete.success"));
        }
        return "redirect:/entradass";
    }

}
